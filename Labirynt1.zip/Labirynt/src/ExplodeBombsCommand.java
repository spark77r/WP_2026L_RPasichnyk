package org.example;

public class ExplodeBombsCommand implements Command {

    private MazeModel model;

    public ExplodeBombsCommand(MazeModel model) {
        this.model = model;
    }

    @Override
    public void execute() {
        model.explodeAll();
    }
}