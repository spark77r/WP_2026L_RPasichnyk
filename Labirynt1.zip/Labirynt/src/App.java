package org.example;

import javax.swing.*;
import java.awt.*;

public class App extends JFrame {

    public App() {
        setSize(900, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MazeModel model = new MazeModel();
        MazePanel panel = new MazePanel(model);

        Command drawCmd = new DrawMazeCommand(model);
        Command explodeCmd = new ExplodeBombsCommand(model);

        JButton drawButton = new JButton("Narysuj labirynt");
        JButton explodeButton = new JButton("Wybuch");

        drawButton.addActionListener(e -> drawCmd.execute());
        explodeButton.addActionListener(e -> explodeCmd.execute());

        JPanel menu = new JPanel(new GridLayout(1, 2));
        menu.add(drawButton);
        menu.add(explodeButton);

        setLayout(new BorderLayout());
        add(menu, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new App().setVisible(true));
    }
}