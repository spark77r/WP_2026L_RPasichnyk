package org.example;

public class DefaultMazeFactory extends MazeFactory {

    @Override
    public Cell createCell(int x, int y) {
        return new Cell(x, y);
    }

    @Override
    public Bomb createBomb(int x, int y) {
        return new Bomb(x, y);
    }
}