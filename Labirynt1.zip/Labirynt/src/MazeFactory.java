package org.example;

public abstract class MazeFactory {
    public abstract Cell createCell(int x, int y);
    public abstract Bomb createBomb(int x, int y);
}