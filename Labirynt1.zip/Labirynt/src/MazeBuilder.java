package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MazeBuilder {

    private final int rows;
    private final int cols;
    private final MazeFactory factory;
    private final Random rnd = new Random();

    public MazeBuilder(int rows, int cols, MazeFactory factory) {
        this.rows = rows;
        this.cols = cols;
        this.factory = factory;
    }

    public Cell[][] buildGrid() {
        Cell[][] grid = new Cell[rows][cols];

        for (int y = 0; y < rows; y++)
            for (int x = 0; x < cols; x++)
                grid[y][x] = factory.createCell(x, y);

        return grid;
    }

    public List<Bomb> placeBombs(int count) {
        List<Bomb> bombs = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            int x = rnd.nextInt(cols);
            int y = rnd.nextInt(rows);
            bombs.add(factory.createBomb(x, y));
        }

        return bombs;
    }
}