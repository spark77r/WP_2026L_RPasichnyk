package org.example;

import java.util.ArrayList;
import java.util.List;

public class MazeModel {

    private Cell[][] grid;
    private List<Bomb> bombs = new ArrayList<>();

    private final List<MazeObserver> observers = new ArrayList<>();

    public void addObserver(MazeObserver obs) {
        observers.add(obs);
    }

    private void notifyObservers() {
        for (MazeObserver o : observers) {
            o.mazeUpdated();
        }
    }

    public Cell[][] getGrid() {
        return grid;
    }

    public List<Bomb> getBombs() {
        return bombs;
    }

    public void setGrid(Cell[][] grid) {
        this.grid = grid;
        notifyObservers();
    }

    public void setBombs(List<Bomb> bombs) {
        this.bombs = bombs;
        notifyObservers();
    }


    public void explodeAll() {
        for (Bomb b : bombs) {
            b.exploded = true;
        }
        notifyObservers();
    }
}
