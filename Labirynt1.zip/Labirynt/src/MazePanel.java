package org.example;

import javax.swing.*;
import java.awt.*;

public class MazePanel extends JPanel implements MazeObserver {

    private MazeModel model;

    public MazePanel(MazeModel model) {
        this.model = model;
        model.addObserver(this);
    }

    @Override
    public void mazeUpdated() {
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Cell[][] grid = model.getGrid();
        if (grid == null) return;

        int size = 60;
        int offsetX = 50;
        int offsetY = 50;

        int gap = size / 3;
        int thickness = 12;

        int w = grid.length;
        int h = grid[0].length;

        for (Cell[] row : grid) {
            for (Cell c : row) {
                int px = offsetX + c.x * size;
                int py = offsetY + c.y * size;

                g.setColor(Color.WHITE);
                g.fillRect(px, py, size, size);

                g.setColor(Color.BLACK);
                g.drawRect(px, py, size, size);
            }
        }

        g.setColor(Color.WHITE);

        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {

                int px = offsetX + x * size;
                int py = offsetY + y * size;

                if (x < w - 1) {
                    g.fillRect(
                            px + size - thickness / 2,
                            py + gap,
                            thickness,
                            size - 2 * gap
                    );
                }

                if (y < h - 1) {
                    g.fillRect(
                            px + gap,
                            py + size - thickness / 2,
                            size - 2 * gap,
                            thickness
                    );
                }
            }
        }

        int mazePx = offsetX;
        int mazePy = offsetY;
        int mazeW = w * size;
        int mazeH = h * size;

        g.setColor(Color.BLACK);
        g.drawRect(mazePx, mazePy, mazeW, mazeH);

        g.setColor(Color.WHITE);
        int doorWidth = size - 2 * gap;

        int topDoorX = 0;
        g.fillRect(
                mazePx + topDoorX * size + gap,
                mazePy - thickness / 2,
                doorWidth,
                thickness
        );

        int bottomDoorX = w - 1;
        g.fillRect(
                mazePx + bottomDoorX * size + gap,
                mazePy + mazeH - thickness / 2,
                doorWidth,
                thickness
        );

        for (Bomb b : model.getBombs()) {

            int cellPx = offsetX + b.x * size;
            int cellPy = offsetY + b.y * size;

            if (!b.exploded) {

                int px = cellPx + 20;
                int py = cellPy + 20;

                
                g.setColor(Color.BLUE);
                g.fillOval(px, py, 20, 20);

            } else {

                
                g.setColor(Color.BLACK);

                int r = 8;
                int midX = cellPx + size / 2;
                int midY = cellPy + size / 2;

                g.fillOval(midX - r / 2, cellPy + 2, r, r);
                g.fillOval(midX - r / 2, cellPy + size - r - 2, r, r);
                g.fillOval(cellPx + 2, midY - r / 2, r, r);
                g.fillOval(cellPx + size - r - 2, midY - r / 2, r, r);
            }
        }
    }
}