package org.example;

public class Bomb {
    public int x;
    public int y;
    public boolean exploded = false;

    public Bomb(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
