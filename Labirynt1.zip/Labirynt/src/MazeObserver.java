package org.example;

public interface MazeObserver {
    void mazeUpdated();
}
