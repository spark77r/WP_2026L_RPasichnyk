package org.example;

public class DrawMazeCommand implements Command {

    private MazeModel model;

    public DrawMazeCommand(MazeModel model) {
        this.model = model;
    }

    @Override
    public void execute() {
        MazeBuilder builder = new MazeBuilder(6, 6, new DefaultMazeFactory());
        model.setGrid(builder.buildGrid());
        model.setBombs(builder.placeBombs(7));
    }
}