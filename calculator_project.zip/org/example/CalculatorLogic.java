package org.example;

public class CalculatorLogic {

    public static String calculate(String text) {
        try {
            String[] parts = text.trim().split(" ");

            if (parts.length != 3)
                return "Error";

            double a = Double.parseDouble(parts[0]);
            double b = Double.parseDouble(parts[2]);
            String op = parts[1];

            double result = switch (op) {
                case "+" -> a + b;
                case "-" -> a - b;
                case "*" -> a * b;
                case "/" -> (b == 0) ? Double.NaN : a / b;
                default -> Double.NaN;
            };

            return String.valueOf(result);

        } catch (Exception e) {
            return "Error";
        }
    }
}
