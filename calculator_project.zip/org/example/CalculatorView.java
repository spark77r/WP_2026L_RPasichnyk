package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorView extends JFrame implements ActionListener {

    private JTextField display;
    private MyGraphicsView screenGr;
    private String text = "";

    public CalculatorView() {
        setTitle("Calculator");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        display = new JTextField();
        display.setFont(new Font("Arial", Font.BOLD, 24));
        display.setHorizontalAlignment(JTextField.RIGHT);

        add(display, BorderLayout.NORTH);

        screenGr = new MyGraphicsView();
        add(screenGr, BorderLayout.SOUTH);

        JPanel buttons = new JPanel(new GridLayout(5, 4));

        String[] btns = {
                "7","8","9","/",
                "4","5","6","*",
                "1","2","3","-",
                "0","+/-","C","+",
                "<-","=","",""
        };

        for (String b : btns) {
            if (b.equals("")) {
                buttons.add(new JLabel());
                continue;
            }
            JButton btn = new JButton(b);
            btn.addActionListener(this);
            buttons.add(btn);
        }

        add(buttons, BorderLayout.CENTER);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = ((JButton)e.getSource()).getText();

        switch (cmd) {
            case "C":
                text = "";
                break;
            case "<-":
                if (text.length() > 0)
                    text = text.substring(0, text.length()-1);
                break;
            case "+/-":
                if (!text.isEmpty()) {
                    if (text.startsWith("-"))
                        text = text.substring(1);
                    else
                        text = "-" + text;
                }
                break;
            case "=":
                text = CalculatorLogic.calculate(text);
                break;
            case "+": case "-": case "*": case "/":
                if (!text.contains(" ") && !text.isEmpty())
                    text += " " + cmd + " ";
                break;
            default:
                text += cmd;
        }

        display.setText(text);
        screenGr.setTex(text);
    }
}
