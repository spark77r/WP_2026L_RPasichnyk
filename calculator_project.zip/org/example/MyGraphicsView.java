package org.example;

import javax.swing.*;
import java.awt.*;

public class MyGraphicsView extends JPanel {

    private String text = "";

    public void setTex(String text) {
        this.text = text;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawString(text, 10, 20);
    }
}
